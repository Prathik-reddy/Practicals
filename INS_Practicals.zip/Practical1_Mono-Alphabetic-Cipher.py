def mono_encrypt(pt):
    a1="abcdefghijklmnopqrstuvwxyz"
    key="defghijklmnopqrstuvwxyzabc"
    en=''
    
    for j in pt.lower():
        for i in a1:
            if i==j:
                en+=key[a1.index(i)]
    print("MonoAlphabatic Encrypted text: ",en)

def mono_decrypt(pt):
    a1="abcdefghijklmnopqrstuvwxyz"
    key="defghijklmnopqrstuvwxyzabc"
    de=''
    for j in pt.lower():
        for i in a1:
            if i==j:
                de+=a1[key.index(i)]
    print("MonoAlphabatic Decrypted text: ",de)
    
pt=input("Enter the plainText: ")
mono_encrypt(pt)
pt=input("Enter the plainText: ")
mono_decrypt(pt)
