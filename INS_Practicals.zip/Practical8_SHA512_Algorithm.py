import hashlib
def sha(m):
    m=m.encode("utf-8")
    hash512=hashlib.sha512(m)
    print("SHA-512 signature of ur mag is:",hash512.hexdigest())
pt=input("Enter a mag:")
sha(pt)
