from itertools import product
from re import findall
array= ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
def datalist_normal(key):
    key=key.replace(" ","")
    key=key.lower()
    list1=list()
    for i in range(len(key)):
        char=key[i]
        if char not in list1:
            if char=='i':
                list1.append('j')
            else:
                list1.append(char)
    for i in range(len(array)):
        char=array[i]
        if char not in list1:
            if char=='i':
                list1.append('j')
            else:
                list1.append(char)
    return list1
def matrix(list1):
    m=[]
    index=0
    for i in range(5):
        a=[]
        for j in range(5):
            a.append(list1[index])
            index=index+1
        m.append(a)
    print("matrix:")
    for i in range(5):
        for j in range(5):
            print(m[i][j],end=" ")
        print()
    return m
def plain(text):
    text=text.replace(" ","")
    p=list()
    for i in range(len(text)):
        char=text[i]
        if char=='i':
            p.append('j')
        else:
            p.append(char)
    for i in range(0,len(p),2):
        if i<len(p)-1:
            if p[i]==p[i+1]:
                p.insert(i+1,"x")
        if len(p)%2!=0:
            p.append("x")
    return p
def enc(p, m):
    encr=""
    for i in range(0,len(p),2):
        print(p[i],":",p[i+1])
        for j in range(5):
            for k in range(5):
                if p[i] == m[j][k]:
                    a=j
                    b=k
        for j in range(5):
            for k in range(5):
                if p[i+1] == m[j][k]:
                    c=j
                    d=k
        if a==c and b!=d:
            encr+=(m[a][(b+1)%5])
            encr+=(m[c][(d+1)%5])
        elif b==d and a!=c:
            encr+=(m[(a+1)%5][b])
            encr+=(m[(c+1)%5][d])
        else:
            encr+=(m[a][d])
            encr+=(m[c][b])
    return encr
def dec(p, m):
    decr=""
    for i in range(0,len(p),2):
        print(p[i],":",p[i+1])
        for j in range(5):
            for k in range(5):
                if p[i] == m[j][k]:
                    a=j
                    b=k
        for j in range(5):
            for k in range(5):
                if p[i+1] == m[j][k]:
                    c=j
                    d=k
        if a==c and b!=d:
            decr+=(m[a][(b-1)%5])
            decr+=(m[c][(d-1)%5])
        elif b==d and a!=c :
            decr+=(m[(a-1)%5][b])
            decr+=(m[(c-1)%5][d])
        else:
            decr+=(m[a][d])
            decr+=(m[c][b])
    return decr
key=input("Enter key:")
text=input("Enter text:")
#creating datalist
list1=datalist_normal(key)
print("Datalist:",list1)
#creating matrix
matrix1=matrix(list1)
#creating plaintext list and adding dummy letters
plaintext=plain(text)
print("Plaintext:",plaintext)
#Creating pairs
#pair(plaintext)
#encrption
encrypt=enc(plaintext, matrix1)
print("Encryped:",encrypt)
#decryption
decrypt=dec(encrypt, matrix1)
print("Decrypted:",decrypt)
