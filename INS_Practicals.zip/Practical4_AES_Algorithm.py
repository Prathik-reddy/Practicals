#AES
import pyaes
aes=pyaes.AESModeOfOperationCTR(b'DESCRYPTDESCRYPT')
plaintext=input("enter text:")
ct=aes.encrypt(plaintext)
print(ct)
aes=pyaes.AESModeOfOperationCTR(b'DESCRYPTDESCRYPT')
plaintext=aes.decrypt(ct)
print(plaintext)
