def encryption(pt, key):
    list1="abcdefghijklmnopqrstuvwxyz"
    en=''
    for i in pt.lower():
        k=(list1.index(i)+key)%26
        en+=list1[k]
    print("Ceaser cipher --> Encrypted Text= ", en)


        
def decryption(pt, key):
    list1="abcdefghijklmnopqrstuvwxyz"
    en=''
    for i in pt.lower():
        k=(list1.index(i)-key)%26
        en+=list1[k]
    print("Ceaser cipher --> Decrypted Text= ", en)

pt=input("Enter the plainText= ")
key=int(input("Key: "))
encryption(pt,key)

pt=input("Enter the plainText= ")
key=int(input("Key: "))
decryption(pt,key)  
